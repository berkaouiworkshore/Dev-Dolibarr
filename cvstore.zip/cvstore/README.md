# CVSTORE FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## Features

Le module CV-Store de workshore.co gère la CV-Théque de votre entreprise.



Other external modules are available on [Dolistore.com](https://www.dolistore.com).

## Translations

Translations can be completed manually by editing files into directories *langs*.





## Licenses

### Main code

GPLv3 or (at your option) any later version. See file COPYING for more information.

### Documentation

All texts and readmes are licensed under GFDL.
